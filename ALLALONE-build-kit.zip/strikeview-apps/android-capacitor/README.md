# ALLALONE — Android (.apk / .aab)

Capacitor wrapper. The app runs in a hardware-accelerated WebView served
over the internal `https://` scheme, so camera, mic, geolocation, Web Audio,
magnetometer and DeviceOrientation all work as they do in Chrome.

## Prerequisites
- Node.js 18+ and npm
- Android Studio (latest) with an SDK + a device/emulator
- JDK 17 (bundled with recent Android Studio)

## Build
```bash
cd android-capacitor
npm install
npx cap add android          # generates the android/ Gradle project
npx cap sync android         # copies www/ into the app

# 1) Add permissions: paste AndroidManifest-permissions.xml into
#    android/app/src/main/AndroidManifest.xml
# 2) (recommended) Replace MainActivity.java with
#    MainActivity-webrtc-snippet.java so the in-WebView camera/mic
#    prompt is auto-granted.

npx cap open android         # opens Android Studio
```
In Android Studio:
- **Debug APK:** Build ▸ Build Bundle(s)/APK(s) ▸ Build APK(s)
- **Release AAB** (for Play): Build ▸ Generate Signed Bundle/APK ▸ Android App Bundle,
  create/select your keystore, Release.

Outputs:
- APK: `android/app/build/outputs/apk/`
- AAB: `android/app/build/outputs/bundle/`

## Updating the app
Replace `www/index.html`, then `npx cap sync android` and rebuild.

## Note on WebUSB (RTL-SDR dongle)
Android WebView does **not** expose WebUSB. For direct-dongle use, open the
app in Chrome on Android (WebUSB works there), or feed the SDR over the
WebSocket bridge — both are already supported in the SOURCE page.
