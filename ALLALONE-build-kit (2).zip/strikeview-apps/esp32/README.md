# ALLALONE — ESP32 host

Serves the ALLALONE UI from an ESP32 over its own Wi-Fi AP — no internet
needed. Great as a portable field unit or as the LoRa/SDR bridge box.

## Build (PlatformIO)
```bash
cd esp32
pio run -t uploadfs      # uploads data/index.html into the ESP32 flash
pio run -t upload        # flashes the firmware
pio device monitor       # shows the IP (192.168.4.1)
```
Then on your phone/laptop: join Wi-Fi **ALLALONE** (password `allalone123`)
and open **http://192.168.4.1**.

## Honest limitation — camera/mic over the AP
Browsers only allow camera & microphone in a **secure context** (HTTPS or
localhost). The ESP32 serves plain `http://192.168.4.1`, so **camera, mic and
torch won't run** in this mode — the radar/scope/flashlight need the installed
Android/Windows app (or the app opened on `https`/localhost).

What **does** work over the ESP32 AP: compass, sky, EMF (phone sensors are
exposed by the browser without a secure context on many Androids), the map,
field guides, SOS/first-aid, deterrent, generator, and — most usefully — the
**SDR/LoRa bridge** pages, since the ESP32 itself can be your bridge radio.

## 8 MB vs 4 MB flash
`huge_app.csv` leaves room for the ~0.25 MB `index.html`. If upload fails,
confirm your board has ≥4 MB flash.
