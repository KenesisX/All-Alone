<p align="center">
  <img src="assets/feature-graphic-1024x500.png" alt="ALLALONE" width="640">
</p>

<h1 align="center">ALLALONE — Sensor Command Suite</h1>

<p align="center">
  <b>Turn any phone, tablet, laptop or Pi into a field sensor command center.</b><br>
  Radar · Scope · Compass · Sky · SDR · Maps · Wildlife · Survival · SOS — one app, five platforms.
</p>

<p align="center">
  <img src="assets/play-icon-512.png" width="96">
</p>

---

## 🟢 What is ALLALONE?

ALLALONE is a single self-contained web app that uses your device's **real
sensors** — camera, microphone, GPS, compass, and magnetometer — to do things
like detect motion, analyze sound, point out satellites, map off-grid, and
send an emergency SOS. Plug in optional radio hardware (an RTL-SDR or LoRa
dongle) and it also shows live RF.

**Most of it works with zero setup and zero internet.** The radio features are
an optional add-on.

---

## 🚀 Try it in 10 seconds

1. Open the app link (your published ALLALONE artifact) on your phone.
2. Tap the gold **◉ ARM ALL** button at the top and **allow** the camera, mic
   and location prompts.
3. Explore the screens from the icon rail on the right. Tap the **?** button
   (top bar) any time for how-to on the current screen.

> 📷 **Camera looks black?** In an embedded preview the browser may block the
> camera. Open the app **full-screen in its own browser tab**, or use one of
> the installed builds below — then it works.

---

## 🧭 The screens

<p align="center"><img src="assets/diagram-pages.png" alt="Pages" width="760"></p>

| Group | Screens | What they do |
|-------|---------|--------------|
| **SENSE** | Radar · Scope · Compass · Sky | Real camera-motion radar (sizes bird→vehicle), zoom scope with filters + photo/video, tilt compass with sun, satellite/star AR |
| **SIGNAL** | Waterfall · Scatter · Sound · Generator · CSI · Packet Lab · UV · Heatmap · Mesh | Live audio/RF spectrum, waveform tools, CSI visualizer |
| **RF / SDR** | Source · TX/Inject · LoRa · Burst · EMF | Link an SDR bridge, control TX hardware, LoRa chat, real magnetometer EMF |
| **FIELD** | Field ID · Listen · Deterrent · Map | Offline ID keys + GPS finds, call analysis + DTMF, wildlife deterrent, multi-layer offline map |
| **SAFETY** | SOS · Flashlight · Perms | GPS emergency beacon + first aid, torch, one-tap permissions |

Plus always-on **⚕ Medical ID** (gold button) on every screen.

---

## 🔌 How it connects

<p align="center"><img src="assets/diagram-architecture.png" alt="Architecture" width="820"></p>

- **No hardware?** Camera, mic, GPS, compass, EMF and every guide/tool work on
  their own.
- **Add a radio?** Run the **bridge** (`bridge/allalone-bridge.py`) on a Pi/PC
  with your dongle; enter its `ws://<ip>:8765` in the app's **Source** page and
  the waterfall/radar fill with real RF.

---

## 💻 Install on your devices

| Platform | Folder | One command | Output |
|----------|--------|-------------|--------|
| 🪟 **Windows** | `windows-electron/` | `npm install && npm run dist` | `.exe` installer + portable |
| 🤖 **Android** | `android-capacitor/` | `npm install && npx cap add android && npx cap sync && npx cap open android` | `.apk` / Play `.aab` |
| 🍓 **Raspberry Pi** | `raspberrypi/` | `./install.sh && sudo reboot` | kiosk (or `.img`) |
| 📡 **ESP32** | `esp32/` | `pio run -t uploadfs && pio run -t upload` | Wi-Fi AP host |
| ⌚ **Galaxy Watch** | `watch/` | load `watch.html` / Wear OS WebView | compass · GPS · SOS · Med ID |

Each folder has its own README with details. Push to GitHub and the included
**Actions** build the Windows `.exe` and Android APK for you automatically
(see `RELEASE.md` for signed Play releases).

---

## 📻 RTL-SDR Blog V4 bridge

```bash
cd bridge
pip install -r requirements.txt
python3 allalone-bridge.py --freq 100e6 --rate 2.4e6 --gain auto
```
Then put `ws://<that-computer-ip>:8765` in the app's **Source** page → **CONNECT**.

> The V4 needs the **rtl-sdr-blog** driver (not the old Osmocom one) — full
> install steps in `bridge/README.md`. The V4 receives **24 MHz – 1.766 GHz**
> (it can't reach 2.4/5 GHz Wi-Fi — the bridge tells you instead of faking it).

---

## 💬 LoRa messaging

Open the **LoRa** page → **🔌 Connect dongle** (plug a LoRa USB module, uses
WebSerial on desktop/Android Chrome) **or** **📡 Use bridge** to route through
your bridge radio. Type and send; incoming messages appear on the left.

---

## 🆘 Medical ID & SOS

- **⚕ Medical ID** (top bar, on every screen): tap to view, **✎ Edit** to add
  conditions, meds, physicians and emergency contacts. Saved only on the
  device. *Also fill your phone's built-in Medical ID for lock-screen access.*
- **SOS** page: pick an incident type, lock GPS, and share a message with your
  coordinates + a map link; **ALL CLEAR** cancels a false alarm, **TEST** runs
  a safe drill, and **LoRa SOS** sends through your bridge radio.

---

## ✅ What a phone can and can't do (straight talk)

| ✅ Real on the phone | ❌ Not possible on a phone (needs hardware / isn't real) |
|---|---|
| Camera motion detection + size/behavior | Thermal imaging (no thermal sensor) — "thermal" is a visual filter |
| Mic FFT, DTMF, sonar, call features | Lie / sickness / blood-pressure detection (not valid science) |
| GPS, compass, **real** magnetometer µT | Transmitting Wi-Fi/BT/LoRa/GSM to "fill the air" (illegal + impossible) |
| Sun/sunrise + GEO satellites (exact math) | CSI / packet radar from the phone alone (needs SDR/ESP32-CSI via bridge) |
| Offline maps, SOS, first aid, deterrents | Tapping private drone/Flock/CCTV feeds (not accessible) |

ALLALONE never fakes a reading. If a feature needs hardware, it says so.

---

## 🛠️ Troubleshooting

- **Camera black** → open full-screen in its own tab, or use a native build;
  on desktop/Pi pick the right camera from the Scope dropdown.
- **Waterfall empty** → tap **◉ MIC** (or link an SDR) so there's a signal.
- **No µT on EMF** → the raw magnetometer API needs Android Chrome full-screen.
- **WebUSB/WebSerial missing** → use desktop or Android Chrome, or the bridge.

---

## 📁 Folder map

```
ALLALONE/
├─ windows-electron/   Windows .exe (Electron)
├─ android-capacitor/  Android .apk/.aab (Capacitor) + icons + Play scripts
├─ raspberrypi/        Pi kiosk + .img notes
├─ esp32/              ESP32 Wi-Fi host
├─ watch/              Galaxy Watch / Wear OS companion
├─ bridge/             RTL-SDR Blog V4 → app bridge (Python)
├─ assets/             icons, Play graphics, diagrams, listing text
├─ .github/workflows/  auto-build Windows + Android, tag → release
├─ RELEASE.md          signed Play .aab + GitHub Releases
└─ README.md           (this file)
```

<p align="center"><sub>Built for Strikeback Tech LLC · use responsibly and only where you're authorized.</sub></p>
