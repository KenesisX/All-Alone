# ALLALONE — Raspberry Pi (.img / kiosk)

Two paths: **(A)** turn a running Pi into an ALLALONE kiosk in ~2 minutes,
or **(B)** bake a custom flashable `.img` with pi-gen.

## A) Kiosk on an existing Pi (fastest)
Start from **Raspberry Pi OS (Bookworm, 64-bit, with Desktop)**.
```bash
cd raspberrypi
chmod +x install.sh run.sh
./install.sh
sudo reboot
```
On boot the Pi serves the app on `http://localhost:8080` (localhost is a
secure context, so camera/mic work) and opens Chromium full-screen.
A Pi Camera or USB webcam is needed for the camera pages.

Run it by hand without the service:
```bash
./run.sh
```

## B) Build a flashable .img (pi-gen)
A true `.img` is produced by Raspberry Pi's own image builder on a Linux
host (it needs root + qemu + binfmt), so it can't be generated inside a
chat sandbox — build it on your machine:

```bash
git clone https://github.com/RPi-Distro/pi-gen
cd pi-gen
# minimal config
cat > config <<'EOF'
IMG_NAME=ALLALONE
TARGET_HOSTNAME=allalone
FIRST_USER_NAME=pi
ENABLE_SSH=1
EOF
# add a custom stage that drops this folder into the image and runs install.sh:
#   stage-allalone/00-run.sh  ->  copies raspberrypi/ to /home/pi/allalone and
#   enables allalone-kiosk.service  (mirror what install.sh does)
sudo ./build.sh
```
The finished image appears in `pi-gen/deploy/ALLALONE-*.img`. Flash it with
Raspberry Pi Imager or `dd`.

## Updating the app
Replace `www/index.html` on the Pi (or in `deploy/`) and reboot.
