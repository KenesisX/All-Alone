# ALLALONE SDR bridge — RTL-SDR Blog V4

Streams your **RTL-SDR Blog V4** into the ALLALONE app over WebSocket. The
app's **SOURCE** page connects to `ws://<host>:8765` and shows live spectrum;
tune/scan commands flow back to the dongle.

## 1. Install the V4 driver (important!)
The V4 needs the **rtl-sdr-blog** driver fork — the old Osmocom `rtl-sdr`
package will not drive it correctly.

**Linux / Raspberry Pi:**
```bash
sudo apt purge ^librtlsdr    # remove old driver
sudo apt install libusb-1.0-0-dev git cmake build-essential
git clone https://github.com/rtlsdrblog/rtl-sdr-blog
cd rtl-sdr-blog && mkdir build && cd build
cmake ../ -DINSTALL_UDEV_RULES=ON
make && sudo make install && sudo ldconfig
# blacklist the TV-tuner driver so the dongle is free:
echo 'blacklist dvb_usb_rtl28xxu' | sudo tee /etc/modprobe.d/blacklist-rtl.conf
sudo reboot
```
Verify: `rtl_test` should print `RTL-SDR Blog V4 Detected`.

**Windows:** install the V4 driver with **Zadig** (WinUSB) per the RTL-SDR Blog
V4 guide, then use the rtl-sdr-blog Windows binaries.

## 2. Run the bridge
```bash
pip install -r requirements.txt
python3 allalone-bridge.py --freq 100e6 --rate 2.4e6 --gain auto
```
It prints `ws://0.0.0.0:8765`. In the app's **SOURCE** page, enter that URL
(use the host's LAN IP from your phone, e.g. `ws://192.168.1.50:8765`) and tap
**CONNECT**. The waterfall, scatter and radar now show real RF.

## V4 specifics (built in)
- Frequency range **24 MHz – 1.766 GHz**. It **cannot** reach 2.4/5 GHz Wi-Fi —
  the bridge tells the app when a tune/scan is out of range instead of lying.
- HF (<24 MHz) uses the V4's built-in HF path — uncomment `set_direct_sampling`
  in the script only if you need it.
- Bias-tee (for an LNA) is commented out — enable with care.
- It's receive-only; `sos` / `lora-tx` / `tx` / `inject` commands are logged and
  are where you wire in your own transmit/LoRa hardware.
